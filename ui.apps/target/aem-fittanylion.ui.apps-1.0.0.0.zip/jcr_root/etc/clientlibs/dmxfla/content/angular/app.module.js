angular.module('fittanyUiApp', [
            'ngResource',
            'ui.router',
    		'ui.bootstrap'
        ]);

