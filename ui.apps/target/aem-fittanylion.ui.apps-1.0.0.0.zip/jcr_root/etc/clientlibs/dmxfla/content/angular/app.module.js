angular.module('fittanyUiApp', [
            'ngResource',
            'ui.router'
        ]);

