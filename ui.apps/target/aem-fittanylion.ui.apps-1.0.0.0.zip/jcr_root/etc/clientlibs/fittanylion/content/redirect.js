function urlRedirect(){
     var currentPath = window.location.pathname;
            if (currentPath == 'wpa') {    
                  $("#header a img").attr("src", "/content/dam/digital-marketing/highmark/purl/highmark-bcbs-delaware-logo.png");
            }

}