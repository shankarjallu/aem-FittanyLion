 $(document).ready(function() {
     console.log = function() {}
 });